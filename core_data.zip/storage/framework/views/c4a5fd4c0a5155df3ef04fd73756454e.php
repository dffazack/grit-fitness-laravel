<?php $__env->startSection('title', 'Kelola Member'); ?>

<?php $__env->startSection('page-title', 'Kelola Member'); ?>
<?php $__env->startSection('page-subtitle', 'Kelola operasional gym dengan mudah dan efisien'); ?>

<?php $__env->startSection('content'); ?>

    
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body p-3">
            <div class="row g-3 align-items-center">
                <div class="col-12 col-md-8 col-lg-6">
                    <form method="GET" action="<?php echo e(route('admin.members.index')); ?>">
                        <div class="input-group">
                            <input type="text" 
                                   name="search" 
                                   class="form-control" 
                                   placeholder="Cari member..." 
                                   value="<?php echo e(request('search')); ?>">
                            <button class="btn btn-primary" type="submit">
                                <i class="bi bi-search"></i>
                                <span class="d-none d-sm-inline ms-1">Cari</span>
                            </button>
                        </div>
                    </form>
                </div>
                <div class="col-12 col-md-4 col-lg-6 text-md-end">
                    <div class="d-flex gap-2 justify-content-end">
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addMemberModal">
                            <i class="bi bi-plus-circle"></i>
                            <span class="d-none d-lg-inline ms-1">Tambah Member</span>
                        </button>
                        <button class="btn btn-outline-secondary" onclick="window.print()">
                            <i class="bi bi-printer"></i>
                            <span class="d-none d-lg-inline ms-1">Print</span>
                        </button>
                        <button class="btn btn-outline-success">
                            <i class="bi bi-file-earmark-excel"></i>
                            <span class="d-none d-lg-inline ms-1">Export</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white border-0 py-3">
            <h5 class="card-title-custom mb-0">
                <i class="bi bi-people me-2 d-none d-sm-inline"></i>
                Manajemen Member
            </h5>
        </div>
        <div class="card-body p-0">
            <?php if($members->isEmpty()): ?>
                <div class="text-center p-5">
                    <i class="bi bi-inbox fs-1 text-muted mb-3"></i>
                    <p class="text-muted mb-0">Tidak ada member yang ditemukan.</p>
                </div>
            <?php else: ?>
                
                <div class="table-responsive d-none d-lg-block">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th class="border-0">Nama</th>
                                <th class="border-0">Email</th>
                                <th class="border-0">Paket</th>
                                <th class="border-0">Status</th>
                                <th class="border-0">Expired</th>
                                <th class="border-0 text-end">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="rounded-circle bg-light d-flex align-items-center justify-content-center me-2"
                                             style="width: 36px; height: 36px;">
                                            <i class="bi bi-person-fill text-muted"></i>
                                        </div>
                                        <strong><?php echo e($member->name); ?></strong>
                                    </div>
                                </td>
                                <td><?php echo e($member->email); ?></td>
                                <td><?php echo e($member->membership->name ?? 'N/A'); ?></td>
                                <td>
                                    <?php if($member->membership_status == 'active'): ?>
                                        <span class="badge rounded-pill bg-active fw-semibold">Active</span>
                                    <?php elseif($member->membership_status == 'pending'): ?>
                                        <span class="badge rounded-pill bg-pending fw-semibold">Pending</span>
                                    <?php else: ?>
                                        <span class="badge rounded-pill bg-danger text-white fw-semibold"><?php echo e(ucfirst($member->membership_status)); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($member->membership_expiry ? $member->membership_expiry->format('d M Y') : 'N/A'); ?></td>
                                <td class="text-end">
                                    <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#detailModal-<?php echo e($member->id); ?>">
                                        <i class="bi bi-eye-fill"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#editMemberModal-<?php echo e($member->id); ?>">
                                        <i class="bi bi-pencil-fill"></i>
                                    </button>
                                    <form action="<?php echo e(route('admin.members.destroy', $member->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Anda yakin ingin menghapus member ini?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="bi bi-trash-fill"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                
                <div class="d-lg-none p-3">
                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mb-3 border">
                        <div class="card-body p-3">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div class="d-flex align-items-center gap-2">
                                    <div class="rounded-circle bg-light d-flex align-items-center justify-content-center"
                                         style="width: 40px; height: 40px;">
                                        <i class="bi bi-person-fill text-muted"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-0 fw-semibold"><?php echo e($member->name); ?></h6>
                                        <small class="text-muted"><?php echo e($member->email); ?></small>
                                    </div>
                                </div>
                                <?php if($member->membership_status == 'active'): ?>
                                    <span class="badge rounded-pill bg-active">Active</span>
                                <?php elseif($member->membership_status == 'pending'): ?>
                                    <span class="badge rounded-pill bg-pending">Pending</span>
                                <?php else: ?>
                                    <span class="badge rounded-pill bg-danger"><?php echo e(ucfirst($member->membership_status)); ?></span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="row g-2 mb-3">
                                <div class="col-6">
                                    <small class="text-muted d-block">Paket</small>
                                    <span class="small fw-semibold"><?php echo e($member->membership->name ?? 'N/A'); ?></span>
                                </div>
                                <div class="col-6">
                                    <small class="text-muted d-block">Expired</small>
                                    <span class="small fw-semibold"><?php echo e($member->membership_expiry ? $member->membership_expiry->format('d M Y') : 'N/A'); ?></span>
                                </div>
                            </div>

                            <div class="d-flex gap-2">
                                <button type="button" class="btn btn-sm btn-primary flex-grow-1" data-bs-toggle="modal" data-bs-target="#detailModal-<?php echo e($member->id); ?>">
                                    <i class="bi bi-eye-fill me-1"></i> Detail
                                </button>
                                <button type="button" class="btn btn-sm btn-warning flex-grow-1" data-bs-toggle="modal" data-bs-target="#editMemberModal-<?php echo e($member->id); ?>">
                                    <i class="bi bi-pencil-fill me-1"></i> Edit
                                </button>
                                <form action="<?php echo e(route('admin.members.destroy', $member->id)); ?>" method="POST" onsubmit="return confirm('Anda yakin ingin menghapus member ini?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger">
                                        <i class="bi bi-trash-fill"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
        
        <?php if($members->hasPages()): ?>
            <div class="card-footer bg-white border-0 py-3">
                <?php echo e($members->withQueryString()->links()); ?>

            </div>
        <?php endif; ?>
    </div>

    
    <div class="modal fade" id="addMemberModal" tabindex="-1" aria-labelledby="addMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form action="<?php echo e(route('admin.members.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="addMemberModalLabel">Tambah Member Baru</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="name" class="form-label">Nama Lengkap</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Alamat Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="mb-3">
                            <label for="password_confirmation" class="form-label">Konfirmasi Password</label>
                            <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan Member</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div class="modal fade" id="detailModal-<?php echo e($member->id); ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content border-0 shadow-lg" style="border-radius: 12px;">
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title">Detail Member</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4 text-center">
                    <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-3" 
                         style="width: 80px; height: 80px; background-color: var(--admin-bg);">
                        <i class="bi bi-person-fill fs-1" style="color: var(--admin-primary);"></i>
                    </div>
                    
                    <h4 class="fw-bold" style="color: var(--admin-primary);"><?php echo e($member->name); ?></h4>
                    <p class="text-muted"><?php echo e($member->email); ?></p>
                    
                    <div class="text-start mt-4">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-2">
                                <span class="text-muted">No. Telepon</span>
                                <span class="fw-semibold"><?php echo e($member->phone ?? 'N/A'); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-2">
                                <span class="text-muted">Status</span>
                                <?php if($member->membership_status == 'active'): ?>
                                    <span class="badge rounded-pill bg-active">Active</span>
                                <?php elseif($member->membership_status == 'pending'): ?>
                                    <span class="badge rounded-pill bg-pending">Pending</span>
                                <?php else: ?>
                                    <span class="badge rounded-pill bg-danger"><?php echo e(ucfirst($member->membership_status)); ?></span>
                                <?php endif; ?>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-2">
                                <span class="text-muted">Paket</span>
                                <span class="fw-semibold"><?php echo e($member->membership->name ?? 'N/A'); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-2">
                                <span class="text-muted">Bergabung</span>
                                <span class="fw-semibold"><?php echo e($member->joined_date ? $member->joined_date->format('d M Y') : 'N/A'); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-2">
                                <span class="text-muted">Expired</span>
                                <span class="fw-semibold"><?php echo e($member->membership_expiry ? $member->membership_expiry->format('d M Y') : 'N/A'); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-2">
                                <span class="text-muted">Sisa Sesi</span>
                                <span class="fw-semibold"><?php echo e($member->remaining_sessions ?? 'N/A'); ?></span>
                            </li>
                        </ul>
                    </div>

                    <?php if($member->transactions->count() > 0): ?>
                    <div class="text-start mt-4">
                        <h6 class="fw-semibold mb-3">Riwayat Transaksi</h6>
                        <div style="max-height: 200px; overflow-y: auto;">
                            <?php $__currentLoopData = $member->transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex justify-content-between align-items-center p-2 border-bottom">
                                    <small><?php echo e($tx->package ?? 'N/A'); ?> (<?php echo e($tx->created_at->format('d M Y')); ?>)</small>
                                    <small class="fw-semibold"><?php echo e($tx->getFormattedAmount()); ?></small>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="editMemberModal-<?php echo e($member->id); ?>" tabindex="-1" aria-labelledby="editMemberModalLabel-<?php echo e($member->id); ?>" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form action="<?php echo e(route('admin.members.update', $member->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="editMemberModalLabel-<?php echo e($member->id); ?>">Edit Member</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="name-<?php echo e($member->id); ?>" class="form-label">Nama Lengkap</label>
                            <input type="text" class="form-control" id="name-<?php echo e($member->id); ?>" name="name" value="<?php echo e($member->name); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="email-<?php echo e($member->id); ?>" class="form-label">Alamat Email</label>
                            <input type="email" class="form-control" id="email-<?php echo e($member->id); ?>" name="email" value="<?php echo e($member->email); ?>" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/hesqiiii/grit-fitness-laravel/resources/views/admin/members/index.blade.php ENDPATH**/ ?>