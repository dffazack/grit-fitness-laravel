<?php $__env->startSection('title', 'Dashboard Member'); ?>

<?php
    // Ambil data user yang sedang login
    $user = Auth::user();
    $isActiveMember = $user->membership_status === 'active';
    $isPendingMember = $user->membership_status === 'pending';
?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">

    
    <div class="mb-4 p-5 rounded-3 text-white" style="background: linear-gradient(90deg, var(--grit-primary), var(--grit-accent));">
        <h1 class="display-5 fw-bold text-white">Dashboard Saya</h1>
        <?php if($isActiveMember): ?>
            <p class="fs-5 opacity-90">Selamat datang kembali, <?php echo e($user->name); ?>! 👋</p>
        <?php elseif($isPendingMember): ?>
            <p class="fs-5 opacity-90">Pembayaran Anda sedang dalam proses verifikasi.</p>
        <?php else: ?>
            <p class="fs-5 opacity-90">Akses penuh tersedia untuk member aktif.</p>
        <?php endif; ?>
    </div>

    
    <?php if($isPendingMember): ?>
        <div class="alert alert-warning border-0 d-flex align-items-center p-4" role="alert" style="background-color: var(--grit-warning-light); color: #664d03;">
            <i class="bi bi-clock-history fs-2 me-3"></i>
            <div>
                <h4 class="alert-heading">Pembayaran Sedang Diverifikasi</h4>
                <p>Tim kami sedang memverifikasi pembayaran Anda (maks. 1x24 jam). Anda akan mendapat notifikasi setelah verifikasi selesai.</p>
                <a href="<?php echo e(route('member.payment')); ?>" class="btn btn-sm btn-warning">Lihat Status Pembayaran</a>
            </div>
        </div>
    <?php endif; ?>

    
    <?php if(!$isActiveMember && !$isPendingMember): ?>
        <div class="alert alert-info border-0 d-flex align-items-center p-4" role="alert" style="background-color: var(--grit-info-light); color: #0c5460;">
            <i class="bi bi-lock-fill fs-2 me-3"></i>
            <div>
                <h4 class="alert-heading">Akses Member Diperlukan</h4>
                <p>Bergabunglah sebagai member untuk mengakses fitur lengkap dashboard, booking kelas, dan benefit eksklusif lainnya.</p>
                <a href="<?php echo e(route('membership')); ?>" class="btn btn-accent text-white">Lihat Paket Membership</a>
                <a href="<?php echo e(route('member.profile')); ?>" class="btn btn-outline-primary ms-2">Edit Profil Saya</a>
            </div>
        </div>
    <?php endif; ?>

    
    <div class="<?php echo e(!$isActiveMember ? 'opacity-25 pe-none' : ''); ?>">
        
        <div class="row g-4 mb-4">
            <div class="col-md-6 col-lg-4">
                <div class="card stat-card h-100">
                    <div class="card-body">
                        <i class="bi bi-calendar-check stat-card-icon text-primary"></i>
                        <h3 class="stat-card-value"><?php echo e($user->membership_expiry ? $user->membership_expiry->format('d M Y') : '-'); ?></h3>
                        <p class="stat-card-label">Masa Aktif Hingga</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="card stat-card h-100">
                    <div class="card-body">
                        <i class="bi bi-patch-check-fill stat-card-icon text-success"></i>
                        <h3 class="stat-card-value text-capitalize"><?php echo e($user->membership_package ?? 'Basic'); ?></h3>
                        <p class="stat-card-label">Status Membership</p>
                    </div>
                </div>
            </div>
            <div class="col-md-12 col-lg-4">
                <div class="card stat-card h-100">
                    <div class="card-body">
                        <i class="bi bi-ticket-detailed stat-card-icon text-accent"></i>
                        <h3 class="stat-card-value"><?php echo e($user->remaining_sessions ?? '0'); ?></h3>
                        <p class="stat-card-label">Sesi Tersisa (jika ada)</p>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="row g-4">
            
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white border-0 pt-4 px-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <h4 class="text-primary">Booking Kelas Saya</h4>
                            <a href="<?php echo e(route('member.bookings.index')); ?>" class="btn btn-outline-primary btn-sm">Lihat Semua</a>
                        </div>
                    </div>
                    <div class="card-body p-4">
                        <div class="list-group list-group-flush">
                            <?php $__empty_1 = true; $__currentLoopData = $myBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="list-group-item d-flex justify-content-between align-items-center px-0 py-3">
                                    <div>
                                        <?php if($booking->classSchedule): ?>
                                            <h6 class="mb-1 text-primary"><?php echo e($booking->classSchedule->custom_class_name ?? $booking->classSchedule->classList->name ?? 'Kelas Dihapus'); ?></h6>
                                            <p class="small text-muted mb-0">
                                                <i class="bi bi-calendar-event me-1"></i> <?php echo e($booking->classSchedule->day); ?>, <?php echo e($booking->classSchedule->start_time->format('H:i')); ?>

                                                <br>
                                                <i class="bi bi-person me-1"></i> <?php echo e($booking->classSchedule->trainer->name ?? 'N/A'); ?>

                                            </p>
                                        <?php else: ?>
                                            <h6 class="mb-1 text-danger">Jadwal Kelas Tidak Tersedia</h6>
                                            <p class="small text-muted mb-0">Jadwal untuk booking ini mungkin telah dihapus.</p>
                                        <?php endif; ?>
                                    </div>
                                    <span class="badge bg-success-light text-success rounded-pill">Booked</span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="text-center py-4">
                                    <i class="bi bi-calendar-x fs-1 text-muted"></i>
                                    <p class="mt-2 text-muted">Belum ada kelas yang Anda booking.</p>
                                    <a href="<?php echo e(route('classes')); ?>" class="btn btn-primary btn-sm mt-2">Booking Kelas Sekarang</a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white border-0 pt-4 px-4">
                        <h4 class="text-primary">Aksi Cepat</h4>
                    </div>
                    <div class="card-body p-4 pt-2">
                        <div class="list-group list-group-flush">
                            <a href="<?php echo e(route('classes')); ?>" class="list-group-item list-group-item-action d-flex align-items-center py-3 px-0">
                                <div class="rounded-circle bg-primary-light d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                    <i class="bi bi-calendar-plus text-primary fs-5"></i>
                                </div>
                                <div>
                                    <h6 class="mb-0">Booking Kelas</h6>
                                    <small class="text-muted">Lihat jadwal & booking</small>
                                </div>
                            </a>
                            <a href="<?php echo e(route('member.payment')); ?>" class="list-group-item list-group-item-action d-flex align-items-center py-3 px-0">
                                <div class="rounded-circle bg-accent-light d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                    <i class="bi bi-credit-card text-accent fs-5"></i>
                                </div>
                                <div>
                                    <h6 class="mb-0">Riwayat Pembayaran</h6>
                                    <small class="text-muted">Lihat transaksi</small>
                                </div>
                            </a>
                            <a href="<?php echo e(route('member.profile')); ?>" class="list-group-item list-group-item-action d-flex align-items-center py-3 px-0">
                                <div class="rounded-circle bg-success-light d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                    <i class="bi bi-person-fill text-success fs-5"></i>
                                </div>
                                <div>
                                    <h6 class="mb-0">Edit Profil</h6>
                                    <small class="text-muted">Update data diri</small>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/hesqiiii/grit-fitness-laravel/resources/views/member/dashboard.blade.php ENDPATH**/ ?>