<?php $__env->startSection('title', 'Paket Membership - GRIT Fitness'); ?>

<?php $__env->startSection('content'); ?>

<div class="membership-page">
    <div class="container py-5">
        
        
        <?php if($studentPackages->isNotEmpty()): ?>
        <div class="package-section mb-5">
            
            <div class="package-header mb-4">
                <div class="d-flex align-items-center gap-3">
                    <div class="package-icon">
                        🎓
                    </div>
                    <div>
                        <h2 class="mb-1 fw-bold">Paket Student</h2>
                        <p class="text-muted mb-0">Khusus untuk pelajar & mahasiswa dengan kartu pelajar aktif</p>
                    </div>
                </div>
            </div>

            
            <div class="row g-4">
                <?php $__currentLoopData = $studentPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6 col-lg-3">
                    <div class="membership-card-v2 h-100 <?php echo e($package->is_popular ? 'recommended' : ''); ?>">
                        
                        
                        <?php if($package->is_popular): ?>
                        <div class="recommended-badge">
                            🔥 Populer
                        </div>
                        <?php endif; ?>

                        
                        <div class="package-duration mb-3">
                            <?php echo e(ucfirst($package->type)); ?> - <?php echo e($package->duration_months); ?> Bulan
                        </div>

                        
                        <div class="package-price mb-3">
                            <h3 class="price-amount mb-0"><?php echo e($package->getFormattedPrice()); ?></h3>
                            <p class="price-period text-muted mb-0">Bulanan</p>
                        </div>

                        
                        <ul class="package-features mb-4">
                            <?php if(is_array($package->features)): ?>
                                <?php $__currentLoopData = $package->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <i class="bi bi-check-circle-fill text-success"></i>
                                    <span><?php echo e($feature); ?></span>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </ul>

                        
                        <div class="mt-auto">
                            <?php if(auth()->guard()->guest()): ?>
                                <a href="<?php echo e(route('register')); ?>" class="btn btn-accent w-100 btn-lg">
                                    Pilih Paket
                                </a>
                            <?php else: ?>
                                <?php if(Auth::user()->membership_status == 'non-member' || Auth::user()->membership_status == 'expired'): ?>
                                    <a href="<?php echo e(route('member.payment', ['package_id' => $package->id])); ?>" class="btn btn-accent w-100 btn-lg">
                                        Pilih Paket
                                    </a>
                                <?php elseif(Auth::user()->membership_package_id == $package->id): ?>
                                    <button class="btn btn-success w-100 btn-lg" disabled>
                                        Paket Anda Saat Ini
                                    </button>
                                <?php else: ?>
                                    <button class="btn btn-outline-secondary w-100 btn-lg" disabled>
                                        Upgrade (Segera Hadir)
                                    </button>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

        
        <?php if($regularPackages->isNotEmpty()): ?>
        <div class="package-section">
            
            <div class="package-header mb-4">
                <div class="d-flex align-items-center gap-3">
                    <div class="package-icon">
                        👑
                    </div>
                    <div>
                        <h2 class="mb-1 fw-bold">Paket Reguler</h2>
                        <p class="text-muted mb-0">Untuk umum dengan fasilitas lengkap dan personal trainer</p>
                    </div>
                </div>
            </div>

            
            <div class="row g-4">
                <?php $__currentLoopData = $regularPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6 col-lg-3">
                    <div class="membership-card-v2 h-100 <?php echo e($package->is_popular ? 'recommended' : ''); ?>">
                        
                        
                        <?php if($package->is_popular): ?>
                        <div class="recommended-badge">
                            🔥 Populer
                        </div>
                        <?php endif; ?>

                        
                        <div class="package-duration mb-3">
                            <?php echo e(ucfirst($package->type)); ?> - <?php echo e($package->duration_months); ?> Bulan
                        </div>

                        
                        <div class="package-price mb-3">
                            <h3 class="price-amount mb-0"><?php echo e($package->getFormattedPrice()); ?></h3>
                            <p class="price-period text-muted mb-0">Bulanan</p>
                        </div>

                        
                        <ul class="package-features mb-4">
                            <?php if(is_array($package->features)): ?>
                                <?php $__currentLoopData = $package->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <i class="bi bi-check-circle-fill text-success"></i>
                                    <span><?php echo e($feature); ?></span>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </ul>

                        
                        <div class="mt-auto">
                            <?php if(auth()->guard()->guest()): ?>
                                <a href="<?php echo e(route('register')); ?>" class="btn btn-primary w-100 btn-lg">
                                    Pilih Paket
                                </a>
                            <?php else: ?>
                                <?php if(Auth::user()->membership_status == 'non-member' || Auth::user()->membership_status == 'expired'): ?>
                                    <a href="<?php echo e(route('member.payment', ['package_id' => $package->id])); ?>" class="btn btn-primary w-100 btn-lg">
                                        Pilih Paket
                                    </a>
                                <?php elseif(Auth::user()->membership_package_id == $package->id): ?>
                                    <button class="btn btn-success w-100 btn-lg" disabled>
                                        Paket Anda Saat Ini
                                    </button>
                                <?php else: ?>
                                    <button class="btn btn-outline-secondary w-100 btn-lg" disabled>
                                        Upgrade (Segera Hadir)
                                    </button>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

        
        <?php if($studentPackages->isEmpty() && $regularPackages->isEmpty()): ?>
        <div class="text-center py-5">
            <div class="empty-state">
                <i class="bi bi-inbox empty-state-icon"></i>
                <p class="empty-state-text">Paket membership belum tersedia.</p>
            </div>
        </div>
        <?php endif; ?>

        
        <?php if($facilities->isNotEmpty()): ?>
        <div class="mt-5 pt-5 border-top">
            <div class="text-center mb-5">
                <h2 class="fw-bold text-primary">Fasilitas Premium Kami</h2>
                <p class="text-muted">Nikmati fasilitas terbaik untuk mendukung latihan Anda</p>
            </div>
            <div class="row g-4">
                <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-3">
                    <div class="card border-0 shadow-sm h-100">
                        <img src="<?php echo e(asset('storage/' . $facility->image)); ?>" 
                             alt="<?php echo e($facility->name); ?>" 
                             class="card-img-top" 
                             style="height: 200px; object-fit: cover;">
                        <div class="card-body">
                            <h5 class="fw-semibold text-center mb-3"><?php echo e($facility->name); ?></h5>
                            <ul class="list-unstyled text-start mb-0">
                                <?php $__currentLoopData = explode(",", $facility->description ?? ''); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(trim($feature)): ?>
                                        <li class="mb-2 d-flex align-items-start">
                                            <i class="bi bi-check-circle-fill text-success me-2 mt-1" style="flex-shrink: 0;"></i>
                                            <span class="small text-muted"><?php echo e(trim($feature)); ?></span>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/hesqiiii/grit-fitness-laravel/resources/views/membership/index.blade.php ENDPATH**/ ?>