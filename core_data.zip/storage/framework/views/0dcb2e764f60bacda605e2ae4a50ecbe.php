

<nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top border-bottom shadow-sm" style="z-index: 1050;">
    <div class="container">
        
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(asset('images/Logo.png')); ?>" alt="GRIT Fitness Logo" style="height: 40px; width: auto;">
        </a>

        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar" aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        
        <div class="collapse navbar-collapse" id="mainNavbar">
            
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                <?php
                    $publicLinks = [
                        ['name' => 'Beranda', 'route' => 'home'],
                        ['name' => 'Kelas & Trainer', 'route' => 'classes'],
                        ['name' => 'Membership', 'route' => 'membership'],
                    ];
                ?>

                <?php if(auth()->guard('web')->check()): ?>
                    <li class="nav-item">
                        <?php
                            // Fallback jika route belum defined (cegah error)
                            $dashboardRoute = Route::has('member.dashboard') ? route('member.dashboard') : route('home');
                            $isActive = request()->routeIs('member.dashboard');
                        ?>
                        <a class="nav-link <?php echo e($isActive ? 'active fw-semibold' : ''); ?>"
                           style="<?php echo e($isActive ? 'color: var(--grit-accent);' : 'color: var(--grit-text);'); ?>"
                           href="<?php echo e($dashboardRoute); ?>">
                           <i class="bi bi-layout-text-sidebar-reverse me-1"></i> Dashboard
                        </a>
                    </li>
                <?php endif; ?>

                
                <?php $__currentLoopData = $publicLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs($link['route']) ? 'active fw-semibold' : ''); ?>"
                           style="<?php echo e(request()->routeIs($link['route']) ? 'color: var(--grit-accent);' : 'color: var(--grit-text);'); ?>"
                           href="<?php echo e(route($link['route'])); ?>">
                           <?php echo e($link['name']); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            
            <div class="d-flex align-items-center">

                <?php if(auth()->guard('admin')->check()): ?>
                    
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary me-2">
                        <i class="bi bi-person-gear me-1"></i> Admin Panel
                    </a>
                    <form action="<?php echo e(route('admin.logout')); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-outline-danger">
                            <i class="bi bi-box-arrow-right me-1"></i> Keluar
                        </button>
                    </form>
                <?php elseif(auth()->guard('web')->check()): ?>
                    
                    <div class="dropdown">
                        <button class="btn border-0 d-flex align-items-center p-0" type="button" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <div class="rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 40px; height: 40px; background-color: var(--grit-primary); color: white;">
                                <i class="bi bi-person-fill fs-5"></i>
                            </div>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 mt-2" aria-labelledby="profileDropdown">
                            <li>
                                <a class="dropdown-item py-2" href="<?php echo e($dashboardRoute); ?>">  
                                    <i class="bi bi-layout-text-sidebar-reverse me-2 text-muted"></i> Dashboard Saya
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item py-2" href="<?php echo e(route('member.profile')); ?>">
                                    <i class="bi bi-person me-2 text-muted"></i> Profil Saya
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item py-2" href="<?php echo e(route('member.payment')); ?>">
                                    <i class="bi bi-credit-card me-2 text-muted"></i> Riwayat Pembayaran
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item py-2" href="<?php echo e(route('member.bookings.index')); ?>">
                                    <i class="bi bi-calendar-check me-2 text-muted"></i> Booking Saya
                                </a>
                            </li>
                            <li><hr class="dropdown-divider mx-3"></li>
                            <li>
                                <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item py-2 text-danger">
                                        <i class="bi bi-box-arrow-right me-2"></i> Keluar
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </div>
                <?php else: ?>
                    
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-link text-decoration-none me-2" style="color: var(--grit-primary);">
                        Masuk
                    </a>
                    <a href="<?php echo e(route('register')); ?>" class="btn btn-accent text-white">
                        Daftar Sekarang
                    </a>
                <?php endif; ?>
                
            </div>
        </div>
    </div>
</nav><?php /**PATH /home/hesqiiii/grit-fitness-laravel/resources/views/components/navbar.blade.php ENDPATH**/ ?>