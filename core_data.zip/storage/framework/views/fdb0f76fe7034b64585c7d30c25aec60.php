<?php $__env->startSection('title', 'Data Master - Notifikasi'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.components.datamaster-tabs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    

    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <strong>Error!</strong> Terdapat kesalahan pada input Anda.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white border-0 py-3">
            <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center gap-3">
                <h5 class="card-title-custom mb-0">
                    <i class="bi bi-bell me-2 d-none d-sm-inline"></i>
                    Banner Notifikasi Homepage
                </h5>
                <button type="button" class="btn btn-accent" data-bs-toggle="modal" data-bs-target="#addNotificationModal">
                    <i class="bi bi-plus-circle me-1"></i>
                    <span class="d-none d-sm-inline">Tambah Notifikasi</span>
                    <span class="d-sm-none">Tambah</span>
                </button>
            </div>
        </div>
        <div class="card-body p-0">
            <?php if($notifications->isEmpty()): ?>
                <div class="text-center p-5">
                    <i class="bi bi-bell-slash fs-1 text-muted mb-3 d-block"></i>
                    <p class="text-muted mb-0">Belum ada notifikasi yang dibuat.</p>
                </div>
            <?php else: ?>
                
                <div class="list-group list-group-flush d-none d-md-block">
                    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="list-group-item p-3 p-lg-4">
                        <div class="row align-items-center g-3">
                            <div class="col-md-8">
                                
                                <div class="d-flex flex-wrap gap-2 mb-2">
                                    <span class="badge rounded-pill" style="background-color: var(--admin-accent); color: white;">
                                        <i class="bi bi-tag-fill me-1"></i> <?php echo e($notification->type); ?>

                                    </span>
                                    <?php if($notification->is_active): ?>
                                        <span class="badge rounded-pill bg-active">
                                            <i class="bi bi-check-circle-fill me-1"></i> Aktif
                                        </span>
                                    <?php else: ?>
                                        <span class="badge rounded-pill bg-secondary text-white">
                                            <i class="bi bi-x-circle-fill me-1"></i> Non-Aktif
                                        </span>
                                    <?php endif; ?>
                                </div>
                                
                                
                                <p class="fw-semibold mb-1" style="color: var(--admin-primary);"><?php echo e($notification->title); ?></p>
                                <p class="text-muted small mb-2"><?php echo e($notification->content); ?></p>
                                <p class="text-muted small mb-0">
                                    <i class="bi bi-calendar-event me-1"></i>
                                    Periode: <?php echo e($notification->start_date->format('d M Y')); ?> - <?php echo e($notification->end_date->format('d M Y')); ?>

                                </p>
                            </div>
                            
                            
                            <div class="col-md-4">
                                <div class="d-flex flex-wrap gap-2 justify-content-md-end">
                                    
                                    <form action="<?php echo e(route('admin.notifications.toggle', $notification)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-warning">
                                            <i class="bi bi-toggle-<?php echo e($notification->is_active ? 'on' : 'off'); ?> me-1 d-none d-lg-inline"></i>
                                            <?php echo e($notification->is_active ? 'Non-aktifkan' : 'Aktifkan'); ?>

                                        </button>
                                    </form>
                                    
                                    
                                    <button type="button" class="btn btn-sm btn-primary"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editNotificationModal-<?php echo e($notification->id); ?>">
                                        <i class="bi bi-pencil-fill me-1"></i>
                                        <span class="d-none d-lg-inline">Edit</span>
                                    </button>
                                    
                                    
                                    <form action="<?php echo e(route('admin.notifications.destroy', $notification)); ?>" method="POST" onsubmit="return confirm('Anda yakin ingin menghapus notifikasi ini?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="bi bi-trash-fill"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                
                <div class="d-md-none p-3">
                    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mb-3 border">
                        <div class="card-body p-3">
                            
                            <div class="d-flex flex-wrap gap-2 mb-3">
                                <span class="badge rounded-pill" style="background-color: var(--admin-accent); color: white;">
                                    <i class="bi bi-tag-fill me-1"></i> <?php echo e($notification->type); ?>

                                </span>
                                <?php if($notification->is_active): ?>
                                    <span class="badge rounded-pill bg-active">
                                        <i class="bi bi-check-circle-fill me-1"></i> Aktif
                                    </span>
                                <?php else: ?>
                                    <span class="badge rounded-pill bg-secondary text-white">
                                        <i class="bi bi-x-circle-fill me-1"></i> Non-Aktif
                                    </span>
                                <?php endif; ?>
                            </div>
                            
                            
                            <h6 class="fw-semibold mb-2" style="color: var(--admin-primary);"><?php echo e($notification->title); ?></h6>
                            <p class="text-muted small mb-3"><?php echo e(Str::limit($notification->content, 120)); ?></p>
                            
                            
                            <div class="d-flex align-items-center gap-2 mb-3 pb-3 border-bottom">
                                <i class="bi bi-calendar-event text-muted"></i>
                                <small class="text-muted">
                                    <?php echo e($notification->start_date->format('d M Y')); ?> - <?php echo e($notification->end_date->format('d M Y')); ?>

                                </small>
                            </div>

                            
                            <div class="d-grid gap-2">
                                
                                <form action="<?php echo e(route('admin.notifications.toggle', $notification)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-warning w-100">
                                        <i class="bi bi-toggle-<?php echo e($notification->is_active ? 'on' : 'off'); ?> me-1"></i>
                                        <?php echo e($notification->is_active ? 'Non-aktifkan' : 'Aktifkan'); ?>

                                    </button>
                                </form>
                                
                                
                                <div class="d-flex gap-2">
                                    <button type="button" class="btn btn-sm btn-primary flex-grow-1"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editNotificationModal-<?php echo e($notification->id); ?>">
                                        <i class="bi bi-pencil-fill me-1"></i> Edit
                                    </button>
                                    
                                    <form action="<?php echo e(route('admin.notifications.destroy', $notification)); ?>" method="POST" onsubmit="return confirm('Anda yakin ingin menghapus notifikasi ini?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="bi bi-trash-fill"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
        
        <?php if($notifications->hasPages()): ?>
            <div class="card-footer bg-white border-0 py-3">
                <?php echo e($notifications->links()); ?>

            </div>
        <?php endif; ?>
    </div>

    
    <div class="modal fade" id="addNotificationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-lg">
            <div class="modal-content border-0 shadow-lg" style="border-radius: 12px;">
                <form action="<?php echo e(route('admin.notifications.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="form_type" value="add">
                    
                    <div class="modal-header border-0">
                        <h5 class="modal-title">Tambah Notifikasi Baru</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    
                    <div class="modal-body p-3 p-md-4">
                        
                        <div class="mb-3">
                            <label class="form-label">Judul Notifikasi</label>
                            <input type="text" 
                                   class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="title" 
                                   value="<?php echo e(old('title')); ?>" 
                                   placeholder="cth: Promo Spesial Kemerdekaan" 
                                   required>
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <div class="invalid-feedback"><?php echo e($message); ?></div> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        
                        <div class="mb-3">
                            <label class="form-label">Konten Notifikasi</label>
                            <textarea class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                      name="message" 
                                      rows="3" 
                                      placeholder="Tulis konten notifikasi..."
                                      required><?php echo e(old('message')); ?></textarea>
                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <div class="invalid-feedback"><?php echo e($message); ?></div> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="row g-3">
                            
                            <div class="col-12 col-md-6">
                                <label class="form-label">Tipe</label>
                                <select class="form-select <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="type" required>
                                    <option value="" disabled selected>Pilih tipe...</option>
                                    <?php $__currentLoopData = \App\Models\Notification::TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type); ?>" <?php echo e(old('type') == $type ? 'selected' : ''); ?>>
                                            <?php echo e($type); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                    <div class="invalid-feedback"><?php echo e($message); ?></div> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            
                            <div class="col-12 col-md-6">
                                <label class="form-label">Status Awal</label>
                                <div class="form-check form-switch mt-2">
                                    <input class="form-check-input" 
                                           type="checkbox" 
                                           role="switch" 
                                           name="is_active" 
                                           value="1" 
                                           checked>
                                    <label class="form-check-label">Langsung Aktifkan</label>
                                </div>
                            </div>
                        </div>

                        <div class="row g-3 mt-1">
                            
                            <div class="col-12 col-md-6">
                                <label class="form-label">Tanggal Mulai</label>
                                <input type="date" 
                                       class="form-control <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       name="start_date" 
                                       value="<?php echo e(old('start_date')); ?>" 
                                       required>
                                <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                    <div class="invalid-feedback"><?php echo e($message); ?></div> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            
                            <div class="col-12 col-md-6">
                                <label class="form-label">Tanggal Selesai</label>
                                <input type="date" 
                                       class="form-control <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       name="end_date" 
                                       value="<?php echo e(old('end_date')); ?>" 
                                       required>
                                <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                    <div class="invalid-feedback"><?php echo e($message); ?></div> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-footer border-0">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="bi bi-x-lg me-1 d-none d-sm-inline"></i>
                            Batal
                        </button>
                        <button type="submit" class="btn btn-accent">
                            <i class="bi bi-plus-circle me-1 d-none d-sm-inline"></i>
                            Tambah Notifikasi
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    
    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="editNotificationModal-<?php echo e($notification->id); ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-lg">
            <div class="modal-content border-0 shadow-lg" style="border-radius: 12px;">
                <form action="<?php echo e(route('admin.notifications.update', $notification)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden" name="form_type" value="edit">
                    <input type="hidden" name="notification_id" value="<?php echo e($notification->id); ?>">
                    
                    <div class="modal-header border-0">
                        <h5 class="modal-title">Edit Notifikasi</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    
                    <div class="modal-body p-3 p-md-4">
                        
                        <div class="mb-3">
                            <label class="form-label">Judul Notifikasi</label>
                            <input type="text" 
                                   class="form-control" 
                                   name="title" 
                                   value="<?php echo e(old('title', $notification->title)); ?>" 
                                   required>
                        </div>
                        
                        
                        <div class="mb-3">
                            <label class="form-label">Konten Notifikasi</label>
                            <textarea class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                      name="message" 
                                      rows="3" 
                                      required><?php echo e(old('message', $notification->message)); ?></textarea>
                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <div class="invalid-feedback"><?php echo e($message); ?></div> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="row g-3">
                            
                            <div class="col-12 col-md-6">
                                <label class="form-label">Tipe</label>
                                <select class="form-select" name="type" required>
                                    <?php $__currentLoopData = \App\Models\Notification::TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type); ?>" <?php echo e((old('type', $notification->type) == $type) ? 'selected' : ''); ?>>
                                            <?php echo e($type); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            
                            
                            <div class="col-12 col-md-6">
                                <label class="form-label">Status</label>
                                <div class="form-check form-switch mt-2">
                                    <input class="form-check-input" 
                                           type="checkbox" 
                                           role="switch" 
                                           name="is_active" 
                                           value="1" 
                                           <?php echo e($notification->is_active ? 'checked' : ''); ?>>
                                    <label class="form-check-label">Aktif</label>
                                </div>
                            </div>
                        </div>

                        <div class="row g-3 mt-1">
                            
                            <div class="col-12 col-md-6">
                                <label class="form-label">Tanggal Mulai</label>
                                <input type="date" 
                                       class="form-control" 
                                       name="start_date" 
                                       value="<?php echo e(old('start_date', $notification->start_date->format('Y-m-d'))); ?>" 
                                       required>
                            </div>
                            
                            
                            <div class="col-12 col-md-6">
                                <label class="form-label">Tanggal Selesai</label>
                                <input type="date" 
                                       class="form-control" 
                                       name="end_date" 
                                       value="<?php echo e(old('end_date', $notification->end_date->format('Y-m-d'))); ?>" 
                                       required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-footer border-0">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="bi bi-x-lg me-1 d-none d-sm-inline"></i>
                            Batal
                        </button>
                        <button type="submit" class="btn btn-accent">
                            <i class="bi bi-save me-1 d-none d-sm-inline"></i>
                            Simpan Perubahan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Auto-show modal jika ada validation error
    document.addEventListener('DOMContentLoaded', function() {
        <?php if($errors->any()): ?>
            <?php if(old('form_type') === 'add'): ?>
                var addModal = new bootstrap.Modal(document.getElementById('addNotificationModal'));
                addModal.show();
            <?php elseif(old('form_type') === 'edit' && old('notification_id')): ?>
                var editModal = new bootstrap.Modal(document.getElementById('editNotificationModal-<?php echo e(old('notification_id')); ?>'));
                editModal.show();
            <?php endif; ?>
        <?php endif; ?>
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    /* ===============================================================
      FIX: MODAL FOOTER TENGGELAM DI LAYAR BESAR
      ===============================================================
      Kita paksa layout modal menggunakan Flexbox
      untuk memastikan footer (tombol) selalu terlihat.
    */
    
    /* 1. Batasi tinggi KESELURUHAN modal agar tidak "tumpah" dari layar */
    .modal-dialog .modal-content {
        max-height: 85vh;  /* 85% tinggi layar, bisa disesuaikan (cth: 90vh) */
        display: flex;
        flex-direction: column;
    }

    /* * 2. Paksa <form> di dalam modal untuk mengisi ruang.
     * Ini PENTING karena <form> Anda membungkus header, body, dan footer.
     */
    .modal-content form {
        display: flex;
        flex-direction: column;
        flex-grow: 1;    /* Paksa form untuk mengisi sisa ruang */
        min-height: 0;   /* Fix bug overflow aneh di flexbox */
    }

    /* 3. Kunci ukuran header dan footer */
    .modal-content .modal-header,
    .modal-content .modal-footer {
        flex-shrink: 0; /* Jangan biarkan header/footer menyusut */
    }

    /* * 4. Buat HANYA modal-body yang bisa di-scroll
     * dan mengisi sisa ruang di tengah.
     */
    .modal-content .modal-body {
        flex-grow: 1;       /* Ambil semua sisa ruang di tengah */
        overflow-y: auto;   /* HANYA body yang bisa di-scroll */
        min-height: 0;      /* Fix bug overflow aneh di flexbox */
    }
    /* =============================================================== */
    

    /* Style untuk Badge (dari kode Anda sebelumnya) */
    .badge {
        white-space: normal;
        word-break: break-word;
    }
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/hesqiiii/grit-fitness-laravel/resources/views/admin/notifications/index.blade.php ENDPATH**/ ?>