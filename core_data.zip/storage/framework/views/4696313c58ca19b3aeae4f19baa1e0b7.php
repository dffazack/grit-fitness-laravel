<?php $__env->startSection('title', 'Kelas & Trainer - GRIT Fitness'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    
    <div class="text-center mb-5">
        <h1 class="text-primary fw-bold">Jadwal Kelas & Trainer</h1>
        <p class="text-muted">Temukan kelas yang cocok dan kenali trainer profesional kami.</p>
    </div>

    
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('classes')); ?>" method="GET">
                <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label for="filterDay" class="form-label small">Filter Hari:</label>
                        <select id="filterDay" name="day" class="form-select form-select-sm">
                            <option value="all">Semua Hari</option>
                            <option value="Senin" <?php echo e(($filterDay ?? '') === 'Senin' ? 'selected' : ''); ?>>Senin</option>
                            <option value="Selasa" <?php echo e(($filterDay ?? '') === 'Selasa' ? 'selected' : ''); ?>>Selasa</option>
                            <option value="Rabu" <?php echo e(($filterDay ?? '') === 'Rabu' ? 'selected' : ''); ?>>Rabu</option>
                            <option value="Kamis" <?php echo e(($filterDay ?? '') === 'Kamis' ? 'selected' : ''); ?>>Kamis</option>
                            <option value="Jumat" <?php echo e(($filterDay ?? '') === 'Jumat' ? 'selected' : ''); ?>>Jumat</option>
                            <option value="Sabtu" <?php echo e(($filterDay ?? '') === 'Sabtu' ? 'selected' : ''); ?>>Sabtu</option>
                            <option value="Minggu" <?php echo e(($filterDay ?? '') === 'Minggu' ? 'selected' : ''); ?>>Minggu</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="filterType" class="form-label small">Filter Tipe Kelas:</label>
                        <select id="filterType" name="class_type" class="form-select form-select-sm">
                            <option value="all">Semua Tipe</option>
                            <option value="Cardio" <?php echo e(($filterType ?? '') === 'Cardio' ? 'selected' : ''); ?>>Cardio</option>
                            <option value="Strength" <?php echo e(($filterType ?? '') === 'Strength' ? 'selected' : ''); ?>>Strength</option>
                            <option value="Yoga" <?php echo e(($filterType ?? '') === 'Yoga' ? 'selected' : ''); ?>>Yoga</option>
                            <option value="HIIT" <?php echo e(($filterType ?? '') === 'HIIT' ? 'selected' : ''); ?>>HIIT</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <button type="submit" class="btn btn-primary btn-sm w-100">Terapkan Filter</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="row g-4">
        <?php $__empty_1 = true; $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day => $daySchedules): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-12">
                <h3 class="mb-3 text-primary"><?php echo e($day); ?></h3>
                <div class="row g-3">
                    <?php $__currentLoopData = $daySchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="card h-100 border-0 shadow-sm">
                                <div class="card-body d-flex flex-column p-3 p-md-4">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <h5 class="card-title text-primary mb-0"><?php echo e($schedule->custom_class_name ?? $schedule->classList->name ?? 'N/A'); ?></h5>

                                        <?php
                                            $remaining = max(0, ($schedule->max_quota ?? 0) - ($schedule->quota ?? 0));
                                            $ratio = ($schedule->max_quota > 0) ? ($schedule->quota / $schedule->max_quota) : 0;
                                            $badgeClass = $remaining <= 0 ? 'bg-danger' : ($ratio < 0.5 ? 'bg-success' : 'bg-warning');
                                        ?>
                                        <span class="badge <?php echo e($badgeClass); ?> text-white small">
                                            Sisa <?php echo e($remaining); ?>

                                        </span>
                                    </div>

                                    <p class="card-subtitle mb-2 text-muted small">
                                        <i class="bi bi-clock me-1"></i>
                                        <?php echo e(\Carbon\Carbon::parse($schedule->start_time)->format('H:i')); ?> - <?php echo e(\Carbon\Carbon::parse($schedule->end_time)->format('H:i')); ?>

                                        <br class="d-inline d-md-none">
                                        <i class="bi bi-person me-1"></i> <?php echo e($schedule->trainer->name ?? 'N/A'); ?>

                                    </p>

                                    
                                    <p class="card-text small text-muted flex-grow-1 d-none d-md-block">
                                        <?php echo e(Str::limit($schedule->description ?? '-', 140)); ?>

                                    </p>

                                    
                                    <div class="d-block d-md-none">
                                        <a class="btn btn-link p-0 small" data-bs-toggle="collapse" href="#sched-desc-<?php echo e($schedule->id); ?>" role="button" aria-expanded="false" aria-controls="sched-desc-<?php echo e($schedule->id); ?>">
                                            Lihat Detail
                                        </a>
                                        <div class="collapse mt-2" id="sched-desc-<?php echo e($schedule->id); ?>">
                                            <p class="small text-muted mb-2"><?php echo e($schedule->description ?? '-'); ?></p>
                                        </div>
                                    </div>

                                    <div class="mt-auto pt-3">
                                        
                                        <?php if(auth()->guard()->check()): ?>
                                            <?php if(Auth::user()->hasActiveMembership()): ?>
                                                <?php
                                                    $isBooked = in_array($schedule->id, $userBookings);
                                                    $isFull = ($schedule->quota ?? 0) >= ($schedule->max_quota ?? 0);
                                                ?>

                                                <form action="<?php echo e(route('member.bookings.store', $schedule->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-accent btn-sm w-100" <?php echo e($isFull || $isBooked ? 'disabled' : ''); ?>>
                                                        <?php if($isFull): ?>
                                                            Kelas Penuh
                                                        <?php elseif($isBooked): ?>
                                                            Sudah Dibooking
                                                        <?php else: ?>
                                                            Booking Kelas
                                                        <?php endif; ?>
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('membership')); ?>" class="btn btn-secondary btn-sm w-100">Upgrade Membership</a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary btn-sm w-100">Login untuk Booking</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="alert alert-info text-center">
                    Belum ada jadwal kelas yang tersedia.
                </div>
            </div>
        <?php endif; ?>
    </div>

    
    <div class="mt-5 pt-5 border-top">
        <div class="text-center mb-5">
            <h2 class="text-primary fw-bold">Tim Trainer Profesional Kami</h2>
            <p class="text-muted">Didukung oleh pelatih bersertifikasi dengan passion membara.</p>
        </div>

        <div class="row g-4">
            <?php $__empty_1 = true; $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                
                <div class="col-12 col-md-6 col-lg-3">
                    <div class="card border-0 shadow-sm text-center h-100">
                        <div class="card-body d-flex flex-column align-items-center p-3 p-md-4">
                            <img src="<?php echo e($trainer->image ? asset('storage/' . $trainer->image) : 'https://via.placeholder.com/150'); ?>"
                                 class="rounded-circle mb-3 shadow" alt="<?php echo e($trainer->name); ?>"
                                 style="width: 120px; height: 120px; object-fit: cover;">
                            <h5 class="fw-bold mb-1 text-primary"><?php echo e($trainer->name); ?></h5>
                            <p class="small text-accent mb-2"><?php echo e($trainer->specialization); ?></p>
                            <p class="small text-muted mb-2"><?php echo e($trainer->experience ?? '-'); ?> Pengalaman | <?php echo e($trainer->clients ?? 0); ?> Klien</p>
                            <p class="small text-muted text-center mb-3 d-none d-md-block"><?php echo e(Str::limit($trainer->bio ?? '-', 120)); ?></p>

                            
                            <div class="d-block d-md-none w-100">
                                <p class="small text-muted text-center mb-2"><?php echo e(Str::limit($trainer->bio ?? '-', 80)); ?></p>
                            </div>

                            
                            
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="alert alert-info text-center">
                        Data trainer belum tersedia.
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>


<style>
    /* Fokus pada mobile (≤576px) */
    @media (max-width: 576px) {
        .card .card-body {
            padding: 0.9rem;
        }
        .card .card-title {
            font-size: 1rem;
        }
        .card .card-subtitle {
            font-size: 0.85rem;
        }
        .card .card-text {
            font-size: 0.85rem;
        }
        /* trainer image sedikit lebih kecil di mobile */
        .card img.rounded-circle {
            width: 100px !important;
            height: 100px !important;
        }
        /* badge kecil lebih proporsional */
        .badge {
            font-size: .75rem;
            padding: .35em .5em;
        }
        /* tombol full width di mobile (sudah w-100), beri ukuran touch-friendly */
        .btn {
            font-size: 0.95rem;
            padding: .45rem .6rem;
        }
    }

    /* Desktop adjustments */
    @media (min-width: 992px) {
        .card .card-title {
            font-size: 1.05rem;
        }
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/hesqiiii/grit-fitness-laravel/resources/views/classes/index.blade.php ENDPATH**/ ?>