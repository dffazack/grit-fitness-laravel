<?php echo e($slot); ?>

<?php /**PATH /home/hesqiiii/grit-fitness-laravel/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>