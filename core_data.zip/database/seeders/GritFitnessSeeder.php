<?php

namespace database\seeders; // <-- PASTIKAN NAMESPACE INI BENAR!

use Illuminate\Database\Seeder;

// use App\Models\User; // Import model yang Anda butuhkan

class GritFitnessSeeder extends Seeder // <-- PASTIKAN NAMA CLASS INI BENAR!
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // ... (Kode untuk membuat Admin, Member, dll.)
        // Contoh:
        // User::create([... Admin data ...]);
        // User::create([... Member data ...]);
    }
}
