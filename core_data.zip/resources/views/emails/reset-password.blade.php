<p>Halo,</p>

<p>Kami menerima permintaan reset password untuk akun Anda.</p>

<p>
    <a href="{{ $url }}">Reset Password</a>
</p>

<p>Jika Anda tidak meminta reset, abaikan email ini.</p>
