<p>Halo {{ $user->name }},</p>

<p>Silakan klik link berikut untuk memverifikasi email Anda:</p>

<p>
    <a href="{{ $verificationUrl }}">
        Verifikasi Email
    </a>
</p>

<p>Jika Anda tidak membuat akun, abaikan email ini.</p>
